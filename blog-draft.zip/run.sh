rm -rf /opt/lampp/htdocs/blog-draft/ && 
cp /media/A412A5B312A58B3E/alumni-cell-git-repo/blog-draft/ /opt/lampp/htdocs/blog-draft/ -R && 
sudo chmod 777 -R /opt/lampp/htdocs/
